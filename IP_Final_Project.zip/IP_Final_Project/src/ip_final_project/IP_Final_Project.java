/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ip_final_project;
import java.awt.event.*;
import java.awt.*;

/**
 *
 * @author Mayank Kumar
 */

public class IP_Final_Project {

    /**
     * @param args the command line arguments
     */
    
 
        
 
 
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic heres
        Splash_Screen s=new Splash_Screen();
        s.setVisible(true);
        try
        {
            Thread.sleep(4000);
            Home_super o=new Home_super();
            o.setVisible(true);
            //close method
            
            WindowEvent winClosingEvent = new WindowEvent(s,WindowEvent.WINDOW_CLOSING);
            Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosingEvent);
        }
        
        catch(InterruptedException e)
        {
            ;
        }
    }
    
}
